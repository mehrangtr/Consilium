# Consilium Governance Pack v1.3 — Reviewed, Executable Integrity Checks

This revision preserves the IDs, titles, priorities, origin, lock and original requirement text of all 30 requirements in the supplied v1.2 archive. It fixes contradictory contract wording and stale views, and adds executable checks for this governance package.

**Application implementation: UNVERIFIED. Application runtime requirements verified: 0/30. V1 application conformance: BLOCKED.** The source tree for the actual application was not supplied. This does not establish that no application code exists elsewhere.

## Files

- `requirements/USER_CONSTRAINTS.yaml` — authoritative list of user-origin requirements (`UR-*`).
- `requirements/AI_RECOMMENDATIONS.yaml` — later AI/researcher recommendations (`AR-*`) and their decisions.
- `requirements/CONFORMANCE_MAP.yaml` — planned contract/module/test/gate mapping; paths are plans.
- `requirements/TRACEABILITY_MATRIX.md` — generated coverage view, never edited independently.
- `requirements/AUDIT_ALIAS_MAP.yaml` — 26 user and 42 recommendation audit aliases; no new user IDs.
- `requirements/INVARIANTS.yaml` — 16 derived, unexecuted application conformance obligations.
- `governance/CHANGE_CONTROL.md` — rule preventing silent override of user requirements.
- `governance/ADR_USER_REQUIREMENT_CHANGE_TEMPLATE.md` — mandatory template for any proposed material change.
- `CONTRACT_ADDENDUM_USER_GUARD_v1.3.md` — generated normative view of canonical records.
- `GOVERNANCE_MANIFEST.json` — inventory and SHA-256 hashes, excluding the manifest itself.
- `evidence/PROVENANCE.json` — source fingerprints; source commit is null because no Git checkout was supplied.
- `evidence/CONFORMANCE_REPORT.md` — generated evidence status; no fabricated runtime passes.
- `evaluation/PILOT_DATASET.json` and `evaluation/EVAL_RUBRIC_FA.md` — 20 synthetic pilot tasks and evaluation protocol; no model benchmark results are claimed.
- `tools/` and `tests/` — document-integrity checks, deterministic archive builder and mutation/regression tests.

## Run the package checks

Python 3.12 and the pinned dependency in `requirements-dev.txt` are the documented CI environment. The local tests were executed with the interpreter version recorded in the evidence file.

```bash
python3 -m pip install -r requirements-dev.txt
bash ci/run-governance-checks.sh
python3 tools/governance.py check --release
```

The last command deliberately exits with code 2 because the application requirements have no supplied runtime evidence. A successful governance check does not certify Browser operation, crash recovery or actual rendered report quality.

## Compatible editing and packaging

```bash
python3 tools/governance.py generate
python3 tools/governance.py manifest
bash ci/run-governance-checks.sh
python3 tools/build_package.py --output ../Consilium_User_Guarded_Governance_v1.3_Reviewed.zip
```

The generated contract and matrix must match the canonical records exactly. The checker rejects original protected-text changes, missing mappings, rejected AR support dependencies, duplicate YAML keys, unsafe paths, stale projections, unlisted files and changed file hashes. These checks detect bounded integrity failures; they cannot automatically prove the semantic correctness of every new implementation clause, and a manifest is not an authenticity signature against a malicious editor with full access.

## V1 connection guarantee and implementation scope

A conformant V1 application retains API, Browser/Web Account and Manual fallback. It retains user-controlled login, valid-conversation reuse, the normal user gate, user-selected Judge, dissent, all required Markdown/JSON histories and real resume semantics. Manual/Mock prototypes remain internal development builds. Optional graph, full Event Sourcing, formal models and autonomous Browser repair do not replace those requirements.

The lexical Bidi checker is improved and non-mutating, but it is not the product renderer or a visual/semantic proof. GitHub, VS Code and Consilium rendering fixtures remain unexecuted application release obligations.

## Canonical source and history

Only `requirements/USER_CONSTRAINTS.yaml` is the active user-requirement registry. `implementation_contract` provides normative clarification while the original `requirement` text is preserved verbatim. The original v1.2 requirement file in `evidence/baseline-v1.2/` is an archived provenance fixture, not a second active registry.

The old v1.1/v1.2 archives remain historical versions. Their different hashes are expected version changes. The alleged working-directory hashes in the audit exactly match v1.1; the historical separate working directory was not supplied for independent inspection. Do not label this fact alone as proven current-source corruption.

CI templates can be integrated into a real repository. No GitHub branch/ruleset setting or external deployment was changed by this review.

## Core rule

> User-origin requirements are protected constraints.  
> AI/researcher recommendations are advisory and may not override them without explicit user approval.

## Recommended integration order

1. Commit this package.
2. Treat `USER_CONSTRAINTS.yaml` as a release-gate input.
3. Merge the addendum into the canonical contract.
4. Add conformance tests for every `UR-*` marked `MUST`.
5. Require ADR approval for any future requirement delta.


## Persian/English Markdown rendering

The user requires all Consilium-generated `.md` reports to remain readable when Persian and English technical content are mixed.

Added:

- `governance/MARKDOWN_REPORT_RENDERING_CONTRACT_FA.md`
- `requirements/REPORT_BIDI_POLICY.yaml`
- `templates/MODEL_REPORT_TEMPLATE_FA.md`
- `tools/check_markdown_bidi.py`

This is protected as `UR-030`.
