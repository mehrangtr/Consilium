#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PYTHONDONTWRITEBYTECODE=1
python3 tools/governance.py check
python3 tools/check_markdown_bidi.py templates/MODEL_REPORT_TEMPLATE_FA.md evaluation/EVAL_RUBRIC_FA.md
python3 -m unittest discover -s tests -v
