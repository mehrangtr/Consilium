# Consilium — Generated Conformance Report

Runtime results are derived from the recorded evidence state, not from document completeness.

| ID | Contract | Application implementation | Runtime verification |
|---|---|---|---|
| `UR-001` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-002` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-003` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-004` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-005` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-006` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-007` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-008` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-009` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-010` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-011` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-012` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-013` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-014` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-015` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-016` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-017` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-018` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-019` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-020` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-021` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-022` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-023` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-024` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-025` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-026` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-027` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-028` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-029` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |
| `UR-030` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` |

Verified application requirements: **0/30**.

**V1 application conformance: BLOCKED — application source and runtime evidence not supplied.**

A passing governance check verifies this package, not Browser operation, crash recovery, blind-review semantics or rendered Bidi output.
