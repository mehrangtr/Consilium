# ADR-XXXX — Proposed Change to Protected User Requirement

- Status: PROPOSED
- Date:
- Author:
- Affected requirements: UR-...
- Related recommendations: AR-...

## Current protected behavior

Describe the exact current behavior.

## Proposed change

Describe the requested delta precisely.

## Why the change is needed

Provide concrete technical evidence. Avoid vague claims such as "cleaner" or "best practice."

## Alternatives considered

1.
2.
3.

## Impact

### User intent / UX
### Reliability / recovery
### Security / privacy
### Data compatibility / migrations
### Browser/API/manual behavior
### Testing / benchmarks

## Compatibility classification

- [ ] Implementation-only, no behavior change
- [ ] Compatible enhancement
- [ ] Material requirement change — explicit user approval required

## Rollback plan

Describe how to restore the previous behavior.

## User approval

- Decision: PENDING
- Approved by:
- Approval date:
- User notes:

> Until `Decision: APPROVED`, this ADR MUST NOT modify the canonical user requirement.
