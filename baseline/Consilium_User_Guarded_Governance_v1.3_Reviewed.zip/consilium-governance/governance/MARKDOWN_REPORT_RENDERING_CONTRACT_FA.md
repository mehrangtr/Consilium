# Consilium Markdown Report Rendering Contract — FA/EN Bidi Safety v1.0

این سند یک قرارداد هنجاری برای تمام گزارش‌های `Markdown` تولیدشده توسط `Consilium` است.

## 1. هدف

تمام خروجی‌های فارسی که شامل اصطلاحات فنی انگلیسی هستند باید در نمایشگرهای رایج `Markdown` خوانا بمانند و ترتیب متن به دلیل ترکیب `RTL` و `LTR` به‌هم نریزد.

این الزام شامل تمام خروجی‌های زیر است:

- گزارش هر Participant
- گزارش Peer Review
- گزارش Round Analysis
- گزارش Judge
- گزارش Final Synthesis
- فایل `debate.md`
- فایل‌های `participants/<model>.md`
- فایل‌های `assessments/<model>.md`
- فایل `final-report.md`
- گزارش‌های Recovery و Diagnostic
- هر خروجی `.md` دیگری که توسط پروژه یا مدل‌های متصل تولید می‌شود

این الزام یک `UR-*` محافظت‌شده است و با شناسه `UR-030` ثبت شده است.

---

## 2. اصل معماری

گزارش خام مدل نباید مستقیماً به‌عنوان فایل نهایی `.md` ذخیره شود.

مسیر استاندارد:

```text
Model Response
↓
Report Parser / Structured Report
↓
Markdown Report Renderer
↓
Bidi-Safe Formatter
↓
Markdown Validator
↓
Persisted .md Report
```

بنابراین کیفیت نمایش گزارش نباید وابسته به این باشد که هر مدل به‌صورت مستقل قواعد راست‌به‌چپ و چپ‌به‌راست را درست رعایت کند.

---

## 3. Source of Truth

محتوای معنایی گزارش از State و Structured Report می‌آید.

```text
Semantic Content
= Canonical / Structured Data

Markdown
= Derived Human-Readable Artifact
```

لایه Formatting حق ندارد معنی، نتیجه، امتیاز، ادعا، مخالفت یا تصمیم مدل را تغییر دهد.

---

## 4. قواعد اجباری نگارش

### 4.1 متن توضیحی

متن توضیحی باید تا حد ممکن به‌صورت جمله فارسی یکپارچه نوشته شود.

اصطلاحات فنی کوتاه باید با `inline code` جدا شوند.

نمونه صحیح:

> وضعیت Participant در این مرحله به `WAITING_USER_DECISION` تغییر می‌کند.

نمونه نامطلوب:

> وضعیت WAITING_USER_DECISION Participant در این مرحله تغییر می‌کند.

---

### 4.2 شناسه‌ها و Enumها

تمام موارد زیر باید داخل `inline code` قرار گیرند:

- State
- Enum
- شناسه
- کلید JSON
- نام تابع
- نام کلاس
- متغیر
- نام مدل در صورتی که وسط جمله فنی قرار می‌گیرد
- نام Provider
- نام فایل کوتاه

نمونه:

> عملیات با شناسه `operation_id` در وضعیت `UNKNOWN_DELIVERY` باقی ماند.

---

### 4.3 مسیر فایل

مسیرهای فایل باید یا در `inline code` قرار گیرند یا در خط مستقل نمایش داده شوند.

نمونه:

```text
participants/claude.md
```

بهتر از قرار دادن مسیر طولانی وسط جمله فارسی است.

---

### 4.4 جریان‌ها و معماری

Flowها نباید در یک جمله ترکیبی فارسی/انگلیسی نوشته شوند.

از block جدا استفاده شود:

```text
Round 1
↓
Blind Peer Review
↓
User Decision
```

سپس توضیح فارسی در پاراگراف بعدی نوشته شود.

---

### 4.5 فرمان‌ها، کد و JSON

فرمان، کد، JSON، YAML و Schema همیشه در fenced code block قرار می‌گیرند.

```yaml
state: WAITING_USER_DECISION
continuity: NATIVE
```

---

### 4.6 URLها

URL طولانی نباید وسط جمله فارسی خام قرار گیرد.

ترجیح:

```text
https://example.com/path
```

یا در Markdown Link استاندارد با متن فارسی یا انگلیسی کوتاه.

---

### 4.7 عدد + واحد انگلیسی

برای جلوگیری از اختلال جهت، عبارت ترکیبی ترجیحاً در `inline code` نوشته شود.

نمونه:

> Timeout برابر `30 s` تنظیم شده است.

---

### 4.8 نام فایل و Extension

نمونه صحیح:

> گزارش در فایل `final-report.md` ذخیره می‌شود.

---

## 5. قواعد جدول

جدول‌های Markdown در متن ترکیبی می‌توانند در بعضی Rendererها مشکل جهت داشته باشند.

بنابراین:

1. ستون توضیحی ترجیحاً فارسی باشد.
2. مقادیر فنی در `inline code` قرار گیرند.
3. از قرار دادن چند عبارت طولانی انگلیسی و فارسی در یک سلول خودداری شود.
4. اگر جدول پیچیده باعث اختلال شد، آن بخش به زیرعنوان و پاراگراف تبدیل شود.
5. کیفیت خوانایی بر فشردگی جدول اولویت دارد.

نمونه:

| مورد | مقدار |
|---|---|
| وضعیت | `WAITING_USER_DECISION` |
| حالت اتصال | `BROWSER` |
| روش بازیابی | `RECOVERED_NEW_ACCOUNT` |

---

## 6. Headingها

Heading فارسی ترجیح داده می‌شود.

اگر شناسه فنی لازم است:

```markdown
## وضعیت بازیابی — `UNKNOWN_DELIVERY`
```

از Headingهای بسیار طولانی و ترکیبی اجتناب شود.

---

## 7. پرهیز از کنترل‌های نامرئی Unicode

به‌صورت پیش‌فرض نباید برای اصلاح جهت متن، کاراکترهای نامرئی مانند `LRM`، `RLM` یا embeddingهای دستی به کل فایل تزریق شوند.

دلیل:

- Debug دشوار
- Copy/Paste نامطمئن
- اختلاف رفتار Rendererها
- احتمال ایجاد تغییرات نامرئی در Git diff

اولویت با ساختار قابل‌مشاهده Markdown است:

```text
Persian prose
+
inline code
+
separate code blocks
```

کنترل‌های Unicode فقط در یک مورد محدود و تست‌شده می‌توانند استفاده شوند و باید توسط Renderer مرکزی اعمال شوند، نه توسط مدل‌ها.

---

## 8. HTML direction tags

استفاده عمومی از:

```html
<div dir="rtl">
```

نباید تنها راه‌حل پروژه باشد؛ چون رفتار Rendererهای مختلف یکسان نیست.

پروژه باید حتی بدون HTML اختصاصی نیز تا حد ممکن خوانا باقی بماند.

Renderer اختصاصی UI می‌تواند در لایه نمایش از `dir="rtl"` استفاده کند، ولی فایل Markdown باید مستقل از آن نیز ساختار قابل‌فهم داشته باشد.

---

## 9. Structured Report Intermediate Representation

بهتر است خروجی مدل ابتدا به یک ساختار میانی تبدیل شود.

نمونه مفهومی:

```json
{
  "title": "تحلیل Round دوم",
  "sections": [
    {
      "type": "paragraph",
      "language": "fa",
      "content": "..."
    },
    {
      "type": "technical_value",
      "content": "WAITING_USER_DECISION"
    },
    {
      "type": "code",
      "language": "json",
      "content": "{...}"
    }
  ]
}
```

`Markdown Report Renderer` مسئول تبدیل این ساختار به Markdown ایمن است.

---

## 10. Bidi-Safe Formatter

این ماژول باید:

- شناسه‌های فنی را تشخیص دهد؛
- نام فایل و Path را isolate کند؛
- blockهای code را دست‌نخورده نگه دارد؛
- Flowهای چندخطی را از پاراگراف فارسی جدا کند؛
- از rewrite معنایی جلوگیری کند؛
- Headingها و جدول‌ها را از نظر خوانایی بررسی کند.

این ماژول Formatting انجام می‌دهد، نه Summarization.

---

## 11. Markdown Validator

قبل از ذخیره هر فایل `.md`، Validator باید حداقل موارد زیر را بررسی کند:

- وجود خط‌های مشکوک با اختلاط شدید فارسی و انگلیسی؛
- Path یا Enum طولانی بدون isolation؛
- code fence ناقص؛
- جدول‌های دارای cellهای بسیار پیچیده دو جهته؛
- وجود direction-controlهای نامرئی غیرمجاز؛
- خراب شدن blockهای JSON/YAML/code؛
- تغییر محتوای معنایی در مرحله Formatting.

Validator در صورت Failure نباید محتوا را حذف کند.

رفتار مجاز:

```text
VALID
↓
Save

NEEDS_FORMAT_NORMALIZATION
↓
Normalize
↓
Validate Again

STILL_UNSAFE
↓
Save Raw Artifact Separately
+
Mark Report Formatting Warning
```

---

## 12. رفتار هنگام گزارش صحیح

اگر یک فایل Markdown از ابتدا درست، خوانا و بدون مشکل جهت است:

> MUST NOT rewrite unnecessarily.

این بند برای جلوگیری از تغییر بی‌دلیل خروجی‌های سالم است.

---

## 13. Model Prompt Contract

هر Participant که گزارش فارسی تولید می‌کند باید یک Formatting Instruction مشترک دریافت کند:

```text
Write Persian prose as coherent RTL paragraphs.
Wrap English technical identifiers, filenames, paths, enums,
commands, JSON keys, model/provider names used technically,
and code tokens in Markdown inline code.
Put long technical sequences, flows, commands, JSON, YAML,
and file paths on separate lines or fenced code blocks.
Do not rely on invisible bidi control characters.
Do not change technical meaning for formatting.
```

با این حال، رعایت این Prompt تنها خط دفاعی نیست؛ Renderer مرکزی همچنان الزامی است.

---

## 14. Artifact Rules

فایل‌های زیر باید از همین Renderer عبور کنند:

```text
debate.md
participants/*.md
assessments/*.md
rounds/*.md
reviews/*.md
recovery/*.md
final-report.md
```

اگر Adapter یا Model مستقیماً فایل Markdown تولید کرد، فایل باید قبل از ورود به Artifact Store از `Markdown Validator` عبور کند.

---

## 15. Invariant

```text
BIDI_SAFE_REPORTS
```

تعریف:

> هیچ فایل Markdown نهایی Consilium نباید صرفاً به دلیل ترکیب متن فارسی و محتوای فنی انگلیسی، به‌شکل آشکار غیرقابل‌خواندن یا دارای ترتیب بصری مخدوش ذخیره شود.

---

## 16. Release Gate

برای V1 حداقل باید این تست‌ها وجود داشته باشند:

1. پاراگراف فارسی با `Enum` انگلیسی
2. پاراگراف فارسی با Path
3. جدول فارسی با مقادیر فنی انگلیسی
4. Flow چندخطی
5. JSON داخل گزارش فارسی
6. URL
7. نام چند Provider در یک گزارش
8. متن Judge با Consensus/Dissent
9. فایل cumulative participant history
10. final report بزرگ با چند زبان

هر fixture باید در حداقل این محیط‌ها بررسی شود:

```text
GitHub Markdown
VS Code Markdown Preview
Consilium UI Renderer
```

---

## 17. اصل نهایی

قانون پروژه:

> مدل مسئول محتواست؛ Renderer مسئول نمایش پایدار است.

و:

> Formatting نباید به معنی بازنویسی محتوای فنی یا تغییر نظر مدل باشد.
