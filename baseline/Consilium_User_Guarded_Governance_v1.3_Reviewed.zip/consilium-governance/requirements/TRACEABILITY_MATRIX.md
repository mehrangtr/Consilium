# Consilium — Generated Traceability Matrix

Generated from canonical records and `CONFORMANCE_MAP.yaml`; target code/test paths are plans, not existing application evidence.

| ID | Contract | Implementation | Verification | Planned modules | Planned gates |
|---|---|---|---|---|---|
| `UR-001` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/adapters/browser/adapter.py` | `ur-conformance`, `browser-conformance` |
| `UR-002` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/adapters/base.py`, `src/consilium/adapters/api/adapter.py`, `src/consilium/adapters/manual.py` | `ur-conformance`, `browser-conformance` |
| `UR-003` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/adapters/browser/auth.py` | `ur-conformance`, `browser-conformance` |
| `UR-004` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/debate.py`, `src/consilium/context/builder.py` | `ur-conformance` |
| `UR-005` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/prompt_architect.py` | `ur-conformance` |
| `UR-006` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/round_planner.py` | `ur-conformance` |
| `UR-007` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/state/machine.py` | `ur-conformance` |
| `UR-008` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/round_planner.py` | `ur-conformance` |
| `UR-009` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/peer_review.py` | `ur-conformance` |
| `UR-010` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/peer_review.py`, `src/consilium/context/builder.py` | `ur-conformance` |
| `UR-011` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/judge.py` | `ur-conformance` |
| `UR-012` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/judge.py`, `src/consilium/artifacts/renderer.py` | `ur-conformance` |
| `UR-013` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/analyzer.py`, `src/consilium/context/builder.py` | `ur-conformance` |
| `UR-014` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/analyzer.py` | `ur-conformance` |
| `UR-015` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/adapters/manual.py` | `ur-conformance` |
| `UR-016` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/recovery/engine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-017` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/core/debate.py` | `ur-conformance` |
| `UR-018` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/adapters/browser/conversation.py` | `ur-conformance`, `browser-conformance` |
| `UR-019` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/recovery/engine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-020` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/recovery/privacy.py`, `src/consilium/recovery/engine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-021` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/persistence/events.py`, `src/consilium/artifacts/store.py` | `ur-conformance`, `artifact-conformance` |
| `UR-022` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/renderer.py` | `ur-conformance`, `artifact-conformance` |
| `UR-023` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/assessment.py` | `ur-conformance`, `artifact-conformance` |
| `UR-024` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/store.py` | `ur-conformance`, `artifact-conformance` |
| `UR-025` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/store.py` | `ur-conformance`, `artifact-conformance` |
| `UR-026` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/json_export.py` | `ur-conformance`, `artifact-conformance` |
| `UR-027` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/recovery/engine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-028` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/persistence/operations.py`, `src/consilium/recovery/engine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-029` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/persistence/operations.py`, `src/consilium/state/machine.py` | `ur-conformance`, `recovery-fault-injection` |
| `UR-030` | `PRESENT` | `UNVERIFIED` | `NOT_RUN` | `src/consilium/artifacts/ir.py`, `src/consilium/artifacts/renderer.py`, `src/consilium/artifacts/bidi.py` | `ur-conformance`, `artifact-conformance`, `bidi-renderer-conformance` |
