# گزارش مدل

## مشخصات

- مدل: `<MODEL_NAME>`
- Provider: `<PROVIDER>`
- Debate: `<DEBATE_ID>`
- Round: `<ROUND_ID>`
- نوع گزارش: `<REPORT_TYPE>`
- زبان گزارش: `<REPORT_LANGUAGE>`

## خلاصه

متن فارسی یکپارچه در این بخش نوشته شود. اصطلاحات فنی مانند `UNKNOWN_DELIVERY` یا `WAITING_USER_DECISION` داخل `inline code` قرار گیرند.

## یافته‌های اصلی

### یافته اول

توضیح فارسی.

مقدار فنی مرتبط:

```text
<TECHNICAL_VALUE>
```

### یافته دوم

توضیح فارسی.

## نقاط پذیرفته‌شده

- مورد فارسی با ارجاع فنی `CLAIM-001`
- مورد فارسی با وضعیت `ACCEPTED`

## نقاط ردشده

- مورد فارسی با وضعیت `REJECTED`

## اختلاف‌های حل‌نشده

- توضیح اختلاف بدون مخلوط‌کردن چند عبارت طولانی انگلیسی وسط جمله.

## بررسی همتایان

| مورد | نتیجه |
|---|---|
| وضعیت | `<REVIEW_STATUS>` |
| امتیاز | `<SCORE>` |

## پیشنهاد برای مرحله بعد

توضیح فارسی.

جریان در صورت نیاز:

```text
Current State
↓
Next Task
↓
User Decision
```

## پیوست فنی

```json
{
  "example": "technical content remains isolated"
}
```
