"""Mutation/regression tests: integrity failures cannot become runtime proof."""
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import yaml
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tools import governance as g
from tools.check_markdown_bidi import issues_in
from tools.build_package import build
import zipfile

class GovernanceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)/'package'
        shutil.copytree(g.DEFAULT_ROOT,self.root)
    def tearDown(self):
        self.temp.cleanup()
    def rewrite_yaml(self,path,mutate):
        p=self.root/path
        data=g.read_yaml(p)
        mutate(data)
        p.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False),encoding='utf-8')
    def test_current_package_has_complete_non_runtime_traceability(self):
        self.assertEqual(g.check(self.root),[])
    def test_locked_user_text_change_is_rejected_even_after_regeneration(self):
        self.rewrite_yaml('requirements/USER_CONSTRAINTS.yaml',lambda d:d['requirements'][0].update(requirement='Browser is optional.'))
        g.generate(self.root)
        self.assertTrue(any('protected baseline field changed: requirement' in e for e in g.check(self.root,verify_manifest=False)))
    def test_contract_must_to_should_change_detected_without_metadata_change(self):
        p=self.root/'CONTRACT_ADDENDUM_USER_GUARD_v1.3.md'
        p.write_text(p.read_text().replace('MUST support targeted continuation','SHOULD support targeted continuation'))
        self.assertTrue(any('Generated view is stale or manually altered' in e for e in g.check(self.root,verify_manifest=False)))
    def test_canonical_normative_weakening_is_rejected(self):
        self.rewrite_yaml('requirements/USER_CONSTRAINTS.yaml',lambda d:d['requirements'][7].update(implementation_contract='SHOULD support targeted continuation.'))
        g.generate(self.root)
        self.assertTrue(any('does not begin with MUST' in e for e in g.check(self.root,verify_manifest=False)))
    def test_missing_mapping_is_rejected(self):
        self.rewrite_yaml('requirements/CONFORMANCE_MAP.yaml',lambda d:d['requirements'].pop('UR-008'))
        errors=g.check(self.root,verify_manifest=False)
        self.assertTrue(any('map inventory differs' in e for e in errors))
        self.assertTrue(any('UR-008: missing implementation_plan' in e for e in errors))
    def test_fake_runtime_pass_and_fake_code_stubs_are_rejected(self):
        self.rewrite_yaml('requirements/USER_CONSTRAINTS.yaml',lambda d:d['requirements'][0].update(implementation_status='IMPLEMENTED',verification_status='PASS'))
        p=self.root/'src/consilium/adapters/browser/adapter.py'
        p.parent.mkdir(parents=True)
        p.write_text('# empty stub\n')
        g.generate(self.root)
        self.assertTrue(any('runtime PASS is unsupported' in e for e in g.check(self.root,verify_manifest=False)))
    def test_rejected_recommendation_cannot_be_support_dependency(self):
        self.rewrite_yaml('requirements/CONFORMANCE_MAP.yaml',lambda d:d['requirements']['UR-022']['recommendation_relations'].append({'id':'AR-022','relation':'SUPPORTS_OR_GUARDED_OPTION'}))
        self.assertTrue(any('rejected or unknown AR' in e for e in g.check(self.root,verify_manifest=False)))
    def test_release_blocked_despite_governance_pass(self):
        self.assertTrue(any('V1 release BLOCKED' in e for e in g.check(self.root,release=True)))
    def test_manifest_detects_unlisted_file_and_changed_content(self):
        (self.root/'requirements/UNLISTED.yaml').write_text('example: true\n')
        p=self.root/'templates/MODEL_REPORT_TEMPLATE_FA.md'
        p.write_text(p.read_text()+'\nchanged\n')
        errors=g.check_manifest(self.root)
        self.assertTrue(any('inventory differs' in e for e in errors))
        self.assertTrue(any('digest mismatch' in e for e in errors))
    def test_duplicate_yaml_key_and_escaping_path_rejected(self):
        p=Path(self.temp.name)/'bad.yaml'
        p.write_text('id: UR-001\nid: UR-002\n')
        with self.assertRaises(ValueError): g.read_yaml(p)
        with self.assertRaises(ValueError): g.safe_path(self.root,'../outside')
    def test_build_reproducible_and_extracted_archive_verifies(self):
        a=Path(self.temp.name)/'a.zip'
        b=Path(self.temp.name)/'b.zip'
        build(self.root,a)
        build(self.root,b)
        self.assertEqual(a.read_bytes(),b.read_bytes())
        dest=Path(self.temp.name)/'extracted'
        with zipfile.ZipFile(a) as z: z.extractall(dest)
        self.assertEqual(g.check(dest/'consilium-governance'),[])

class BidiLexicalTests(unittest.TestCase):
    def test_original_template_regression_and_safe_variant(self):
        self.assertTrue(issues_in('Flow در صورت نیاز:'))
        self.assertEqual(issues_in('جریان در صورت نیاز:'),[])
        self.assertEqual(issues_in('وضعیت `UNKNOWN_DELIVERY` ثبت شد.'),[])
    def test_fence_lengths_and_tildes_do_not_expose_inner_code(self):
        self.assertEqual(issues_in('````text\n```\nFlow فارسی\n```\n````'),[])
        self.assertEqual(issues_in('~~~text\nFlow فارسی\n~~~'),[])
        self.assertTrue(issues_in('```text\nunclosed'))
    def test_exact_length_inline_code_and_link_destination(self):
        self.assertEqual(issues_in('عبارت ``a ` b`` درست است.'),[])
        self.assertEqual(issues_in('منبع [راهنما](https://example.test/doc) در دسترس است.'),[])
        self.assertTrue(issues_in('این [Flow](https://example.test) مشکل دارد.'))
    def test_hidden_controls_detected_inside_code_and_input_unchanged(self):
        value='```text\n'+chr(0x202e)+'example\n```'
        original=value
        self.assertTrue(issues_in(value))
        self.assertEqual(value,original)

if __name__=='__main__': unittest.main()
