"""Build a deterministic archive from the verified current governance tree."""
from pathlib import Path
import argparse
import zipfile
if __package__:
    from .governance import DEFAULT_ROOT, check, package_files, MANIFEST
else:
    from governance import DEFAULT_ROOT, check, package_files, MANIFEST

def build(root, output):
    root=Path(root).resolve()
    output=Path(output).resolve()
    if output.is_relative_to(root):
        raise ValueError('Output archive must be outside the source tree')
    errors=check(root)
    if errors:
        raise ValueError('\n'.join(errors))
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name in sorted(package_files(root)+[MANIFEST]):
            info=zipfile.ZipInfo('consilium-governance/'+name,date_time=(2026,10,5,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=(0o644 << 16)
            archive.writestr(info,(root/name).read_bytes())

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=DEFAULT_ROOT)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    build(args.root,args.output)
    print(args.output.resolve())
